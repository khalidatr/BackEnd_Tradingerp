package com.erp.trading_erp.dao.hr;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.erp.trading_erp.dao.GenericRepository;

@Repository
public class AdminRepository extends GenericRepository  {

//	public List<Object []> getAllUserWithName() {
//	return 	entityManager.createQuery("select login.username, l.status, e.firstname, e.lastname from "
//				+ "Login as l inner join l.login  e").getResultList();
//	}
	
	
//	public List<Object []> getAllUserWithName() {
//		return 	entityManager.createQuery("select e.firstname , e.lastname , l.username, l.status from Employee as e    right  join e.login as l "
//				+ "	 ").getResultList();
//		}
	
	
	public List<Object []> getAllUserWithName() {
		return 	entityManager.createQuery("from Employee as emp , Login as login "
				+ "	").getResultList();
		}
	
//	public List<Object []> getAllUserWithName() {
//		return 	entityManager.createNativeQuery(""
//				+ "SELECT Employee.firstname, Employee.lastname"
//				+ "FROM Employee"
//				+ "FULL OUTER JOIN Login ON Employee.loginid=Login.loginid "
//				+ "	").getResultList();
//		}
	

	
		//	select employee.firstname, employee.lastname, login.username, login.status from Employee employee join employee.login login
			
			
			
			
}
