package com.erp.trading_erp.services.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.Sales.CustomerRepository;
import com.erp.trading_erp.dao.Sales.SalesOrderRepository;
import com.erp.trading_erp.entities.sales.Customer;
import com.erp.trading_erp.entities.sales.Sales_order;

@Service
public class SalesOrderService {

	@Autowired
	private SalesOrderRepository salesOrderRepository;
	
	
	
	
	public List<Sales_order> getAllSaleOrder() {
		return salesOrderRepository.fetchEntities(Sales_order.class);
	}
	
	
	
	
	@Transactional
	public Sales_order placeSalesOrder(Sales_order order) {
		return (Sales_order) salesOrderRepository.save(order);
	}
	
	
	@Transactional
	public Sales_order updateSalesOrder(Sales_order order) {
		return (Sales_order) salesOrderRepository.save(order);
	}
	
	
	
}
