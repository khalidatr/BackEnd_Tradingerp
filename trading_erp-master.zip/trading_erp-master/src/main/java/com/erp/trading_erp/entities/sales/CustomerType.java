package com.erp.trading_erp.entities.sales;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum CustomerType {

	@JsonProperty("BUSINESS")
	BUSINESS,
	@JsonProperty("INDIVIDUAL")
	INDIVIDUAL
	
	
}
