package com.erp.trading_erp.dto;

public class EmployeeRecord {

}
