package com.erp.trading_erp.services.hr;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.trading_erp.dao.hr.GatePassRepository;
import com.erp.trading_erp.entities.hr.Visitor;

@Service
public class GatePassService {

	@Autowired
	private GatePassRepository gatePassRepository;
	
	
	@Transactional
	public Visitor insertVisitor(Visitor visitor) {
		return (Visitor) gatePassRepository.save(visitor); //using generic insert method
	}
	
	@Transactional
	public Visitor updateVisitor(Visitor visitor) {
		return (Visitor) gatePassRepository.save(visitor);
		 
	}
	
	public Visitor findVisitor(int id) {
		return gatePassRepository.findByPK(Visitor.class, id);
	}
	
	public List<Visitor> getAllVisitorList(){
		return gatePassRepository.fetchAllVisitors();
	}
}
