package com.erp.trading_erp.entities.sales;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Embeddable
public class Customer_Address {

	@Column(length = 255)
	@JsonProperty
	private String street_no;
	
	
	@Column(name="city")
	private String city_cust;
	
	private String state;
	private String country;
	
	@JsonIgnore
	private int pincode;
	
	
	
	
	
	
	
	public String getCity_cust() {
		return city_cust;
	}
	public void setCity_cust(String city_cust) {
		this.city_cust = city_cust;
	}
	public String getStreet_no() {
		return street_no;
	}
	public void setStreet_no(String street_no) {
		this.street_no = street_no;
	}
	
	
	
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	
	
	
}
