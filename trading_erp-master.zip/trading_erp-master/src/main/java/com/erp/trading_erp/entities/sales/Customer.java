package com.erp.trading_erp.entities.sales;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
@DynamicUpdate
public class Customer {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int customer_id;
	
	@Enumerated(EnumType.STRING)
	private CustomerType customer_type;
	
	private String first_name;
	private String last_name;
	
	
	
	
	@Column(length = 255)
	@JsonProperty
	private String street_no;
	
	
	@Column(name="city")
	private String city_cust;
	
	private String state;
	private String country;
	
	@JsonIgnore
	private String pincode;
	
	
	
	
	
	
	
	
	
	@JsonProperty
	@Column(name = "email_id")
	private String emailId_cust;
	
	@JsonProperty
	private String phone_number;
	private String alternate_phone_number;
	
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Column(length = 250)
	private String remarks;
	

	
	
	
	

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getAlternate_phone_number() {
		return alternate_phone_number;
	}

	public void setAlternate_phone_number(String alternate_phone_number) {
		this.alternate_phone_number = alternate_phone_number;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public CustomerType getCustomer_type() {
		return customer_type;
	}

	public void setCustomer_type(CustomerType customer_type) {
		this.customer_type = customer_type;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	


	


	public String getEmailId_cust() {
		return emailId_cust;
	}

	public void setEmailId_cust(String emailId_cust) {
		this.emailId_cust = emailId_cust;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStreet_no() {
		return street_no;
	}

	public void setStreet_no(String street_no) {
		this.street_no = street_no;
	}

	public String getCity_cust() {
		return city_cust;
	}

	public void setCity_cust(String city_cust) {
		this.city_cust = city_cust;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	

	
	


	
	
}
