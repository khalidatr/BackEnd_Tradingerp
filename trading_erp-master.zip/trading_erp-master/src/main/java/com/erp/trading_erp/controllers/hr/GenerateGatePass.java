package com.erp.trading_erp.controllers.hr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dto.VisitorStatus;
import com.erp.trading_erp.entities.hr.Visitor;
import com.erp.trading_erp.services.hr.GatePassService;

@RestController
@CrossOrigin
public class GenerateGatePass {

	@Autowired
	private GatePassService gatePassService;
	
	
	@PostMapping("/create-gatePass")
	public VisitorStatus createGatePass(@RequestBody Visitor visitor) {
		try {
			System.out.println("***********  "+visitor.getMobileNumber());
			Visitor visitor1 = gatePassService.insertVisitor(visitor);
			//System.out.println(visitor.getMobileNumber());
			VisitorStatus status = new VisitorStatus();
			status.setStatus(true);
			status.setMessage("visitor registered successfully!");
			status.setVisitor_id(visitor1.getVisitor_id());
			status.setFirstname(visitor1.getFirstname());
			status.setLastname(visitor1.getLastname());
			return status;
			
		}catch(RuntimeException ex) {
			VisitorStatus status = new VisitorStatus();
			status.setStatus(false);
			status.setMessage("visitor failed to register ");
			return status;
		}
		
		
	}
	
	@GetMapping("/get-visitor/{id}")
	public Visitor getVisitorInfo(@PathVariable int id) {
		return gatePassService.findVisitor(id);
	}

	@PutMapping("/update-visitor")
	public VisitorStatus updateGatePass(@RequestBody Visitor visitor) {
		try {
			Visitor visitor1 = gatePassService.updateVisitor(visitor);
			VisitorStatus status = new VisitorStatus();
			status.setStatus(true);
			status.setMessage("visitor updated successfully!");
			status.setVisitor_id(visitor1.getVisitor_id());
			return status;
		}catch(RuntimeException ex) {
			VisitorStatus status = new VisitorStatus();
			status.setStatus(false);
			status.setMessage("visitor failed to update ");
			return status;
		}
		
	}

	
	@GetMapping("/get-visitors")
	public List<Visitor> getVisitorInfo() {
		return gatePassService.getAllVisitorList();
	}
	
}
