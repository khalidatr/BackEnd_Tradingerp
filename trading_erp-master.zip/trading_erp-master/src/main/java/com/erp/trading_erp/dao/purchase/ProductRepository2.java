package com.erp.trading_erp.dao.purchase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.erp.trading_erp.entities.purchase.Product;

@Repository
public interface ProductRepository2 extends JpaRepository<Product, Integer> {

}
