package com.erp.trading_erp.dao.hr;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.hr.Visitor;

@Repository
public class GatePassRepository extends GenericRepository {

	public List<Visitor> fetchAllVisitors() {
		return (List<Visitor>)  entityManager.createQuery("select c from Visitor c")
					.getResultList();
	}
	
	
	
	
}
