package com.erp.trading_erp.entities.hr;

public enum Status {

	ENABLED,
	DISABLED 
}
