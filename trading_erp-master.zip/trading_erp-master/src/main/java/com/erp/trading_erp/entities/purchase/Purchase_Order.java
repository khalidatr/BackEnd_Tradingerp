package com.erp.trading_erp.entities.purchase;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
@DynamicUpdate
public class Purchase_Order {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int po_id;
	
	
	
	private String purchase_date;
	
	
	private String due_date;
	
	
	
	private String purchase_time;
	
	
	@OneToOne
	@JoinColumn(name = "supplier_id")
	private Supplier suppplier;
	
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="product_id")
	@JsonIgnore
	@JsonProperty
	private List<Product> products; //keeping it unidirectional only to restrict complexity for time being
	
	
	
	private double total_amount;
	
	private double advance_amount;
	
	private double due_amount;
	
	
	@Enumerated(EnumType.STRING)
	private PaymentType payment_type;


	
	
	
	
	
	
	
	
	public String getPurchase_date() {
		return purchase_date;
	}


	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}


	public String getDue_date() {
		return due_date;
	}


	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}


	public String getPurchase_time() {
		return purchase_time;
	}


	public void setPurchase_time(String purchase_time) {
		this.purchase_time = purchase_time;
	}


	public int getPo_id() {
		return po_id;
	}


	public void setPo_id(int po_id) {
		this.po_id = po_id;
	}


	


	public Supplier getSuppplier() {
		return suppplier;
	}


	public void setSuppplier(Supplier suppplier) {
		this.suppplier = suppplier;
	}


	public List<Product> getProducts() {
		return products;
	}


	public void setProducts(List<Product> products) {
		this.products = products;
	}


	public double getTotal_amount() {
		return total_amount;
	}


	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}


	public double getAdvance_amount() {
		return advance_amount;
	}


	public void setAdvance_amount(double advance_amount) {
		this.advance_amount = advance_amount;
	}


	public double getDue_amount() {
		return due_amount;
	}


	public void setDue_amount(double due_amount) {
		this.due_amount = due_amount;
	}


	public PaymentType getPayment_type() {
		return payment_type;
	}


	public void setPayment_type(PaymentType payment_type) {
		this.payment_type = payment_type;
	}


	@Override
	public String toString() {
		return "Purchase_Order [po_id=" + po_id + ", purchase_date=" + purchase_date + ", due_date=" + due_date
				+ ", purchase_time=" + purchase_time + ", suppplier=" + suppplier + ", products=" + products
				+ ", total_amount=" + total_amount + ", advance_amount=" + advance_amount + ", due_amount=" + due_amount
				+ ", payment_type=" + payment_type + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
