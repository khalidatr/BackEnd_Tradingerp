package com.erp.trading_erp.entities.hr;

public enum Gender {

	MALE,
	FEMALE
}
