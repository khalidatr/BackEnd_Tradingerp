package com.erp.trading_erp.dto;



public class LoginStatus extends GenericStatus{

	
	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
	
	
	
}
