package com.erp.trading_erp.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dto.CustomerDTO;
import com.erp.trading_erp.entities.sales.Customer;
import com.erp.trading_erp.services.sales.CustomerService;

@RestController
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController {

	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/get-all-customer")
	public List<Customer> getAllCustomer() {
		return customerService.getAllCustomer();
	}
	
	@GetMapping("/get-customer/{id}")
	public Customer getCustomerById(@PathVariable int id) {
		return		customerService.getCustomerById(id);
	}
	
	@PostMapping("/save-customer")
	public Customer registerCustomer( @RequestBody Customer customer) {
		return (Customer) customerService.registerCustomer(customer);
	}
	
	
	@PutMapping("/update-customer")
	public Customer updateCustomer( @RequestBody Customer customer) {
		return (Customer) customerService.updateCustomer(customer);
	}
	
	
}
