package com.erp.trading_erp.controllers.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.entities.purchase.Supplier;
import com.erp.trading_erp.services.purchase.SupplierService;

@RestController
@CrossOrigin
@RequestMapping("/supplier")
public class SupplierController {

	
	@Autowired
	private SupplierService supplierService;
	
	@PostMapping("/register-supplier")
	public Supplier registerSupplier(@RequestBody Supplier supplier) {
		return supplierService.registerSupplier(supplier);
	}
	
	@GetMapping("/get-allSupplier")
	public List<Supplier> getSupplierList() {
		return supplierService.fetchAllSupplier();
	}
	
	@PutMapping("/update-supplier")
	public Supplier updateSupplier(@RequestBody Supplier supplier) {
		return supplierService.updateSupplier(supplier);
	}
	
	
	@GetMapping("/get-supplier/{id}")
	public Supplier getSupplierList(@PathVariable int suppplier_id) {
		return (Supplier) supplierService.fetchSupplierById(suppplier_id);
	}
}
