package com.erp.trading_erp.dao.purchase;

import org.springframework.stereotype.Repository;


import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.purchase.Product;

@Repository
public class PurchaseOrderRepository extends GenericRepository{

	public Product getProductByName(String name) {
		return (Product) entityManager.createQuery("from Product where product_name =:em ")
				.setParameter("em", name)
				.getSingleResult();
	}
	
	
}
