package com.erp.trading_erp.entities.sales;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum Sales_payment_type {
	@JsonProperty("CASH")
	CASH,
	@JsonProperty("CHEQUE")
	CHEQUE,
	@JsonProperty("NEFT")
	NEFT,
	@JsonProperty("RTGS")
	RTGS,
	@JsonProperty("UPI")
	UPI,
	
	
	
	
}
