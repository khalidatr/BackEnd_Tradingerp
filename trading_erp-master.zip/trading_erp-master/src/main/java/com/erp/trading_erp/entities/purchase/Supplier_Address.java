package com.erp.trading_erp.entities.purchase;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Supplier_Address {
	
	
	private int postalCode;
	private String country;
	private String city;
	private int streetNo;
	
	
	
	public int getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(int postalCode) {
		this.postalCode = postalCode;
	}
	public String getCountry() {
		return country;
	}
	@Column(length = 25, nullable = false)
	public void setCountry(String country) {
		this.country = country;
	}
	@Column(length = 25, nullable = false)
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(int streetNo) {
		this.streetNo = streetNo;
	}
	
	@Override
	public String toString() {
		return "Address [postalCode=" + postalCode + ", country=" + country + ", city=" + city + ", streetNo="
				+ streetNo + "]";
	}
}
