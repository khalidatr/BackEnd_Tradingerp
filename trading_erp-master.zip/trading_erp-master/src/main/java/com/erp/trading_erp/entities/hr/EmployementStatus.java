package com.erp.trading_erp.entities.hr;

public enum EmployementStatus {

	FREELANCE,
	FULL_TIME_CONTRACT,
	FULL_TIME_PERMANENT,
	FULL_TIME_PROBATION,
	PART_TIME_CONTRACT,
	INTENSHIP
	
}
