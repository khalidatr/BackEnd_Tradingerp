package com.erp.trading_erp.exception;

public class DepartmentException extends RuntimeException {

	public DepartmentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
