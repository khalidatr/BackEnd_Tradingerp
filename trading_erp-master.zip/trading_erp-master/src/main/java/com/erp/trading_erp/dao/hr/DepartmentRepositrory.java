package com.erp.trading_erp.dao.hr;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.hr.Department;

@Repository
public class DepartmentRepositrory extends GenericRepository{

	
	public List<Department> getAllDepartments() {
		return fetchEntities(Department.class);
	}
	
	public Department createNewDept(Department dept) {
		return (Department) save(dept);
	}
	
	public Department updateDept(Department dept) {
		return (Department) save(dept);
	}
	
	
	public Department getDepartmentByDeptName(Department dept) {
		return findByField(Department.class, dept.getDept_name(), "dept_name");
		//1st-class name
		//2nd -field value
		//3rd - fieldName
	}
	
	
}
