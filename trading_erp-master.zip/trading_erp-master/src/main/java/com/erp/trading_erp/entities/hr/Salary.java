package com.erp.trading_erp.entities.hr;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
@DynamicUpdate
public class Salary {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int sal_id;
	
	private String  bank_account;
	private String pan_card_number;
	private String adharcard_number;
	private String UAN;
	
	@OneToMany(mappedBy = "salary")
	@JsonIgnore
	private List<Salary_details> salary_details;
	

	
	
	
	public String getBank_account() {
		return bank_account;
	}
	public void setBank_account(String bank_account) {
		this.bank_account = bank_account;
	}
	public String getAdharcard_number() {
		return adharcard_number;
	}
	public void setAdharcard_number(String adharcard_number) {
		this.adharcard_number = adharcard_number;
	}
	public String getUAN() {
		return UAN;
	}
	public void setUAN(String uAN) {
		UAN = uAN;
	}
	public List<Salary_details> getSalary_details() {
		return salary_details;
	}
	public void setSalary_details(List<Salary_details> salary_details) {
		this.salary_details = salary_details;
	}
	public int getSal_id() {
		return sal_id;
	}
	public void setSal_id(int sal_id) {
		this.sal_id = sal_id;
	}
	
	public String getPan_card_number() {
		return pan_card_number;
	}
	public void setPan_card_number(String pan_card_number) {
		this.pan_card_number = pan_card_number;
	}
	
	
	
}
