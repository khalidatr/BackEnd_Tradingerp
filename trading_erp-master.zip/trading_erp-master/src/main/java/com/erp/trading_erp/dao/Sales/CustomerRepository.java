package com.erp.trading_erp.dao.Sales;

import org.springframework.stereotype.Repository;

import com.erp.trading_erp.dao.GenericRepository;

@Repository
public class CustomerRepository extends GenericRepository {

}
