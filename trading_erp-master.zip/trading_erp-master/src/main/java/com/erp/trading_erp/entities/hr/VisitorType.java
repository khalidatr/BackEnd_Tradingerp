package com.erp.trading_erp.entities.hr;

public enum VisitorType {

	RELATIVES,
	FRIENDS,
	INTERNAL,
	EMPLOYEE_OF_ANOTHER_COMPANY
}
