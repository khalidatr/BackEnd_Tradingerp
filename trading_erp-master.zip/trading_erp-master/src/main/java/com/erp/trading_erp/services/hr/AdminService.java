package com.erp.trading_erp.services.hr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.hr.AdminRepository;
import com.erp.trading_erp.dao.hr.AdminRepository1;
import com.erp.trading_erp.dto.User;
import com.erp.trading_erp.entities.hr.Employee;
import com.erp.trading_erp.entities.hr.Login;
import com.erp.trading_erp.service.GenericService;

@Service
public class AdminService {

	@Autowired
	private AdminRepository adminRepository;
	
	
	
	@Autowired
	private AdminRepository1 adminRepository1;
	
	public boolean doesEmployeeExist(int id) {
		return adminRepository1.existsById(id);
	}
	
	public Login saveLoginCredentials(Login login) {
		return  (Login) adminRepository.save(login);
		 
	}
	
	@Transactional
	public Login saveLoginFromUser(User user) {
		Login login = new Login();
		login.setUsername(user.getUsername());
		login.setPassword(user.getPassword());
		login.setStatus(user.getStatus());
		return saveLoginCredentials(login);
	}
	
	public List<Object []> getAllUser() {
		return adminRepository.getAllUserWithName();
	}
	
	
}
