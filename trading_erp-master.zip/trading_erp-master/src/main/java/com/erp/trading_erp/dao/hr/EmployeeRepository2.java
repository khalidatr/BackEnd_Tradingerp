package com.erp.trading_erp.dao.hr;

import java.util.List;

import org.springframework.stereotype.Repository;


import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.hr.Login;
import com.erp.trading_erp.entities.hr.Status;

@Repository
public class EmployeeRepository2 extends GenericRepository {

	public List<Object[]> fetchEmployeeRecords() {
	return entityManager.createQuery("select ph from Employee e  join"
				+ "e.roll_id 	 r	join e.department_id 	ph     ").getResultList();
	}
	
	Status stat;
	
	public Boolean findUsernameStatus(String username) {
		return (Long) entityManager
			.createQuery("select c from Login as c where c.username = :em and c.status = :stat")
			.setParameter("em", username)
			.setParameter("stat",stat.ENABLED)
			.getSingleResult() == 1 ? true : false;
	}
	
	public Login findByUsernameAndPwd(String username, String password) {


			return (Login) entityManager
					.createQuery("select c from Login as c where c.username = :em "
							+ "and c.password =:pwd  and c.status = :stat")
					.setParameter("em", username)
					.setParameter("pwd", password)
					.setParameter("stat",stat.ENABLED)
					.getSingleResult();

		
	}
	
}
