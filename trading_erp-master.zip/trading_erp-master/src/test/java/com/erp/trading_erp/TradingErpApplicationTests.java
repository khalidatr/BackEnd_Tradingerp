package com.erp.trading_erp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingErpApplicationTests {

	@Test
	void contextLoads() {
	}

}
