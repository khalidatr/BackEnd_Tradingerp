package com.erp.trading_erp.controllers.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dao.purchase.PurchaseOrderRepository;
import com.erp.trading_erp.dto.GenericStatus;
import com.erp.trading_erp.dto.PurchaseOrder_DTO;
import com.erp.trading_erp.entities.purchase.Product;
import com.erp.trading_erp.entities.purchase.Purchase_Order;
import com.erp.trading_erp.services.purchase.PurchaseOrderService;

@RestController
@CrossOrigin
@RequestMapping("/purchase-order")
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderService purchaseOrderService;
	
	@Autowired
	private PurchaseOrderRepository repo3;
	
	
	@PostMapping("/place-order")
	public GenericStatus placePurchaseOrder(@RequestBody Purchase_Order order) {
		try {
			System.out.println(order.getProducts().size());
			System.out.println(order.toString());
			
			purchaseOrderService.placeOrder(order);
			//if success then send a custome message 
			GenericStatus status = new GenericStatus();
			status.setStatus(true);
			return status;
			
		} catch (RuntimeException e) {
			// TODO: handle exception
			//if fail then send a custome message 
			GenericStatus status = new GenericStatus();
			status.setStatus(false);
			return status;
		}
		
	}
	
	@GetMapping("/get-all-puchase")
	public List<Purchase_Order> getPurchaseOrderList() {
		return purchaseOrderService.getOrderList();
	}
	
	@PostMapping("/place-order2")
	public Purchase_Order placePurchaseOrderAnother(@RequestBody Purchase_Order order) {
		Purchase_Order pOrder   = (Purchase_Order) repo3.save(order);
	//	int po = pOrder.getPo_id();
		System.out.println(order.toString());

		List<Product> list = order.getProducts();
		
				
		int js_quant = list.stream().findFirst().get().getQuantity();
		double js_price = list.stream().findFirst().get().getPrice();
		String  pName = list.stream().findFirst().get().getProduct_name();
		
		System.out.println(pName);

		Product prod = repo3.getProductByName(pName);
		System.out.println(prod);
		int d_quant = prod.getQuantity();
		int tot_quant = js_quant + d_quant;
		prod.setQuantity(tot_quant);
		prod.setPrice(js_price);
		
		


		return null;

	}
	
	
	
	
	
}
