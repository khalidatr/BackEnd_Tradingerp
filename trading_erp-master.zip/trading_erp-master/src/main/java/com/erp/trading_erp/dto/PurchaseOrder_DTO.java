package com.erp.trading_erp.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.erp.trading_erp.entities.purchase.PaymentType;
import com.erp.trading_erp.entities.purchase.Product;

public class PurchaseOrder_DTO {

	private String  purchase_date;

	private String  due_date;

	private String purchase_time;

	private int suppplier_id;

	private List<Product> products; // keeping it unidirectional only to restrict complexity for time being

	private double total_amount;

	private double advance_amount;

	private double due_amount;

	private PaymentType payment_type;
	


	
	
	
	
	
	
	
	

	public String getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}

	public String getPurchase_time() {
		return purchase_time;
	}

	public void setPurchase_time(String purchase_time) {
		this.purchase_time = purchase_time;
	}

	public int getSuppplier_id() {
		return suppplier_id;
	}

	public void setSuppplier_id(int suppplier_id) {
		this.suppplier_id = suppplier_id;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public double getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}

	public double getAdvance_amount() {
		return advance_amount;
	}

	public void setAdvance_amount(double advance_amount) {
		this.advance_amount = advance_amount;
	}

	public double getDue_amount() {
		return due_amount;
	}

	public void setDue_amount(double due_amount) {
		this.due_amount = due_amount;
	}

	public PaymentType getPayment_type() {
		return payment_type;
	}

	public void setPayment_type(PaymentType payment_type) {
		this.payment_type = payment_type;
	}

	
	
	
	
	
	
	
}
