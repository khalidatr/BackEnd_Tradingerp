package com.erp.trading_erp.controllers.hr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dto.GenericStatus;
import com.erp.trading_erp.entities.hr.Department;
import com.erp.trading_erp.services.hr.DepartmentService;

@RestController
@RequestMapping("/department")
@CrossOrigin
public class DepartmentController {

	
	@Autowired
	private DepartmentService departmentService;
	
	@GetMapping("/get-dept-list")
	public List<Department>getListDept() {
	return 	departmentService.getAllDepartment();
	}
	
	@PostMapping("/insert-dept")
	public GenericStatus createNewDept(@RequestBody Department dept) {
		try {
			Department dept1 = departmentService.saveDepartment(dept);
			GenericStatus status = new GenericStatus();
			status.setStatus(true);
			status.setMessage("Department registered successfully!");
			return status;
		} catch (RuntimeException e) {
			// TODO: handle exception
			GenericStatus status = new GenericStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage());
			return status;
		}
	}
	
	
	@PutMapping("/update-dept")
	public GenericStatus updateDept(@RequestBody Department dept) {
		try {
			Department dept1 = departmentService.updateDepartment(dept);
			GenericStatus status = new GenericStatus();
			status.setStatus(true);
			status.setMessage("Department updated successfully!");
			return status;
		} catch (RuntimeException e) {
			// TODO: handle exception
			GenericStatus status = new GenericStatus();
			status.setStatus(false);
			status.setMessage("Department failed to update !");
			return status;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
}
