package com.erp.trading_erp.entities.purchase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table
@DynamicUpdate
public class Supplier {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int supplier_id;
	
	private String phone_number;
	private String email_id;
	private String contact_name;
	private String supplier_name;
	
	
	@ManyToMany(mappedBy = "suppliers")
	@JsonIgnoreProperties("suppliers")
	private List<Product> products;
	
	
	@Embedded
	private Supplier_Address address;

	

	
	
	
	
	


	public String getPhone_number() {
		return phone_number;
	}


	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}


	public int getSupplier_id() {
		return supplier_id;
	}


	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}


	


	public String getEmail_id() {
		return email_id;
	}


	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}


	public String getContact_name() {
		return contact_name;
	}


	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}


	public String getSupplier_name() {
		return supplier_name;
	}


	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}


	public List<Product> getProducts() {
		return products;
	}


	public void setProducts(List<Product> products) {
		this.products = products;
	}


	public Supplier_Address getAddress() {
		return address;
	}


	public void setAddress(Supplier_Address address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Supplier [supplier_id=" + supplier_id + ", phone_number=" + phone_number + ", email_id=" + email_id
				+ ", contact_name=" + contact_name + ", supplier_name=" + supplier_name + ", products=" + products
				+ ", address=" + address + "]";
	}
	
	
	
	
	
	
	
	
}

