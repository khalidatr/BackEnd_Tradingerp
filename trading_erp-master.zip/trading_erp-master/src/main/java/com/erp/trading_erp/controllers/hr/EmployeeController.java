package com.erp.trading_erp.controllers.hr;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dto.EmployeeStatus;
import com.erp.trading_erp.dto.LoginStatus;
import com.erp.trading_erp.entities.hr.Employee;
import com.erp.trading_erp.entities.hr.Login;
import com.erp.trading_erp.exception.LoginServiceException;
import com.erp.trading_erp.services.hr.EmployeeService;

@RestController
@CrossOrigin
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/insert-employee")
	public EmployeeStatus insertEmployee(@RequestBody Employee employee) {
		try {
			Employee employee2 = employeeService.saveEmployee(employee);
			EmployeeStatus status = new EmployeeStatus();
			status.setStatus(true);
			status.setMessage("Employee Registered Successfully!");
			status.setEmpid(employee2.getEmpid());
			status.setFirstname(employee2.getFirstname());
			status.setLastname(employee2.getLastname());
			return status;
		} catch (RuntimeException e) {
			EmployeeStatus status = new EmployeeStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage() + "\"Employee failed to Registered !");
			return status;
		}
	}

	@GetMapping("/get-employee/{id}")
	public Optional<Employee> getEmployee(@PathVariable int id) {
		return employeeService.getEmployee(id);
	}

	@PutMapping("/update-employee")
	public EmployeeStatus updateEmployee(@RequestBody Employee employee) {
		try {
			Employee employee2 = employeeService.updateEmployee(employee);
			EmployeeStatus status = new EmployeeStatus();
			status.setStatus(true);
			status.setMessage("Employee Updated Successfully!");
			status.setEmpid(employee2.getEmpid());
			status.setFirstname(employee2.getFirstname());
			status.setLastname(employee2.getLastname());
			return status;
		} catch (RuntimeException e) {
			EmployeeStatus status = new EmployeeStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage() + "\"Employee failed to update !");
			return status;
		}
	}

	@GetMapping("/get-all-employees")
	public List<Employee> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	// fetch employee records just like orange hrm module in pim functionality
	@GetMapping("/fetchEmployeeRecords")
	public List<Object[]> fetchEmployeeRecords() {
		return employeeService.FetchEmployeeRecords();
	}

	@PostMapping("/login")
	public LoginStatus login(@RequestBody Login loginDetails) {
		System.out.println(loginDetails);
		try {
		Login login = employeeService.login(loginDetails);
			
			LoginStatus status = new LoginStatus();
			status.setStatus(true);
			status.setMessage("Login successful!");
			status.setUsername(login.getUsername());
			return status;
			
		} catch (LoginServiceException e) {
			LoginStatus status = new LoginStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage());
			return status;
		}
		
}
	
	
	
	
	
	
	
	
	
	
	
}
