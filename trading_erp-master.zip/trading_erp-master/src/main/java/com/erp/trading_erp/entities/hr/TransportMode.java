package com.erp.trading_erp.entities.hr;

public enum TransportMode {

	BIKE,
	CAR,
	TRUCK
}
