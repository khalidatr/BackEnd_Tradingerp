package com.erp.trading_erp.services.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.Sales.CustomerRepository;
import com.erp.trading_erp.dto.CustomerDTO;
import com.erp.trading_erp.entities.sales.Customer;
import com.erp.trading_erp.entities.sales.Customer_Address;

@Service
public class CustomerService {

	
		@Autowired
		private CustomerRepository customerRepository;
		
		
		public List<Customer> getAllCustomer() {
			return customerRepository.fetchEntities(Customer.class);
		}
		
		
		public Customer getCustomerById(int id) {
			return  customerRepository.findByPK(Customer.class, id);		
		}
		
		@Transactional
		public Customer registerCustomer(Customer customer) {			
			return (Customer) customerRepository.save(customer);
		}
		
		
		@Transactional
		public Customer updateCustomer(Customer customer) {
			return (Customer) customerRepository.save(customer);						
		}
		
		
		
		
		
		public Customer convertDTO_toEntityForNew(CustomerDTO custDto) {
			Customer cust = new Customer();
			cust.setCustomer_id(custDto.getCustomer_id());
			cust.setFirst_name(custDto.getFirst_name());
			cust.setLast_name(custDto.getLast_name());
			cust.setCustomer_type(custDto.getCustomer_type());
			cust.setAlternate_phone_number(custDto.getAlternate_phone_number());
			cust.setPhone_number(custDto.getPhone_number());
			cust.setRemarks(custDto.getRemarks());
			cust.setEmailId_cust(custDto.getEmailId_cust());
//			cust.setCustomer_address(custDto.getStreet_no(),custDto.getCity_cust() ,custDto.getState(), custDto.getCountry(),
//			custDto.getPincode());
			return cust;
			
		}
		
		
		
		public CustomerDTO convertEntityToDTO(Customer custDto) {
			CustomerDTO cust = new CustomerDTO();
			cust.setCustomer_id(custDto.getCustomer_id());
			cust.setFirst_name(custDto.getFirst_name());
			cust.setLast_name(custDto.getLast_name());
			cust.setCustomer_type(custDto.getCustomer_type());
			cust.setAlternate_phone_number(custDto.getAlternate_phone_number());
			cust.setPhone_number(custDto.getPhone_number());
			cust.setRemarks(custDto.getRemarks());
			cust.setEmailId_cust(custDto.getEmailId_cust());
			
//		
			
			return cust;
			
		}
		
		
		
}
