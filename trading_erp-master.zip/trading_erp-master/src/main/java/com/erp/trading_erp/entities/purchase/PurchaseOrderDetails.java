package com.erp.trading_erp.entities.purchase;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "purchase_order_details")
public class PurchaseOrderDetails {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int purchaseOrderDetail_id;
	
	private int po_id;	//purchase order id
	
	private int product_id;
	
	private int quantity;
	

	public int getPurchaseOrderDetail_id() {
		return purchaseOrderDetail_id;
	}

	public void setPurchaseOrderDetail_id(int purchaseOrderDetail_id) {
		this.purchaseOrderDetail_id = purchaseOrderDetail_id;
	}

	public int getPo_id() {
		return po_id;
	}

	public void setPo_id(int po_id) {
		this.po_id = po_id;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
	
}
