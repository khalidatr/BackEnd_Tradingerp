package com.erp.trading_erp.exception;

public class LoginServiceException extends RuntimeException {

	public LoginServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

	
	
}
