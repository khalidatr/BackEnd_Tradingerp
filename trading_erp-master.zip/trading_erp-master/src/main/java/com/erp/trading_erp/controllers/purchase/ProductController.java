package com.erp.trading_erp.controllers.purchase;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.entities.purchase.Product;
import com.erp.trading_erp.services.purchase.ProductService;

@RestController
@CrossOrigin
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping("/get-product-list")
	public List<Product> getAllProduct(){
		return productService.getAllProduct();
		
	}
	
	@PostMapping("/register-product")
	public Product registerProduct(@RequestBody Product product) {
		return productService.registerProduct(product);
	}
	
	@PutMapping("/update-product")
	public Product updateProduct(@RequestBody Product product) {
		return productService.updateProduct(product);
	}
	
	@GetMapping("/get-product/{id}")
	public Product getProductFromId(@PathVariable int id){
		return productService.getProductById(id);
		
	}
	
	
	
	
	
	
}
