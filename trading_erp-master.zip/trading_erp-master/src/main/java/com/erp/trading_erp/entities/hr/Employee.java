package com.erp.trading_erp.entities.hr;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
@DynamicUpdate
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column( updatable = false, nullable = false)
	private int empid;
	
	private String firstname;
	private String lastname;
	private String email;
	
	private String phoneNumber;
	
	private LocalDate hireDate;
	
	@JsonProperty
	private LocalDate BirthDate;
	
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	
	@Enumerated(EnumType.STRING)
	private EmployementStatus employement_status;
	
	@ManyToOne
	@JoinColumn(name = "department_id")
	private Department department;
	
	@OneToOne
	@JoinColumn(name="roll_id")
	private Roles role;
	
	

	@OneToOne
	@JoinColumn(name="loginID")
	private Login login;
	
	@OneToOne
	@JoinColumn(name="addressId")
	private Address_Employee address;
	
	@OneToOne
	@JoinColumn(name="attendance_id")
	private Attendance attendence;
	
	@OneToOne
	@JoinColumn(name="sal_id")
	private Salary salary;
	
	
	
	
	
	
	
	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public EmployementStatus getEmployement_status() {
		return employement_status;
	}

	public void setEmployement_status(EmployementStatus employement_status) {
		this.employement_status = employement_status;
	}

	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}

	public Address_Employee getAddress() {
		return address;
	}

	public void setAddress(Address_Employee address) {
		this.address = address;
	}

	public Attendance getAttendence() {
		return attendence;
	}

	public void setAttendence(Attendance attendence) {
		this.attendence = attendence;
	}

	
	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public LocalDate getBirthDate() {
		return BirthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		BirthDate = birthDate;
	}

	
	
	
	
	
	
	
}
