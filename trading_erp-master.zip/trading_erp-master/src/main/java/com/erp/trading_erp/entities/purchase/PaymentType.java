package com.erp.trading_erp.entities.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum PaymentType {

	CASH,
	CHEQUE,
	DD,
	NEFT,
	RTGS,
	UPI
}
