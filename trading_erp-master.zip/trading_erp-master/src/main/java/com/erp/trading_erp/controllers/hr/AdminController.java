package com.erp.trading_erp.controllers.hr;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.dto.GenericStatus;
import com.erp.trading_erp.dto.User;
import com.erp.trading_erp.entities.hr.Employee;
import com.erp.trading_erp.entities.hr.Login;
import com.erp.trading_erp.entities.hr.Status;
import com.erp.trading_erp.service.GenericService;
import com.erp.trading_erp.services.hr.AdminService;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private GenericService genericService;

	@PostMapping("/add-user")
	public GenericStatus addUser(@RequestBody User user) {
		if (user != null) {
			boolean empStatus = adminService.doesEmployeeExist(user.getEmpid());
			Login login = adminService.saveLoginFromUser(user);
			Employee emp = genericService.findEntity(Employee.class, user.getEmpid());
			emp.setLogin(login);
			GenericStatus status = new GenericStatus();
			status.setMessage("user  added successfully!");
			status.setStatus(true);
			return status;
		}
		return null; 
	}

//	select employee.firstname, employee.lastname, login.username, login.status from Employee employee join employee.login login
	
	
//	@GetMapping("/get-users")
//	public List<User> getAllUsers() {
//		List<Object []> list = adminService.getAllUser();
//		List<User> list_user = new ArrayList<User>();
//		for(Object[] object : list ) {
//			User user = new User();
//				
//			user.setUsername( (String) object[2]);			
//			user.setStatus( (Status)  object[3]);
//			user.setFirstname((String) object[0]);
//			user.setLastname((String) object[1]);
//			list_user.add(user);
//		}
//		return list_user;
//	}
//	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("/get-users")
	public List<Object []> getAllUsers() {
		return  adminService.getAllUser();
	
	}
	
	
	
	
	@PutMapping("/update-user")
	public GenericStatus updateUser(@RequestBody User user) {
		if (user != null) {
			boolean empStatus = adminService.doesEmployeeExist(user.getEmpid());
			Login login = adminService.saveLoginFromUser(user);
			Employee emp = genericService.findEntity(Employee.class, user.getEmpid());
			emp.setLogin(login);
			GenericStatus status = new GenericStatus();
			status.setMessage("user updated successfully!");
			status.setStatus(true);
			return status;
		}
		return null; 
	}
	
	
	
	
	
	
}
