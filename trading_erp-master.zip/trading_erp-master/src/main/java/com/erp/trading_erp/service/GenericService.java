package com.erp.trading_erp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.GenericRepository;

@Service
public class GenericService {

	
	@Autowired
	private GenericRepository genericRepository;
	
	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Object saveEntity(Object object) {
		return genericRepository.save(object);
	}
	

	public <E> E findEntity(Class<E> clazz, Object pk) {
		return genericRepository.findByPK(clazz, pk);
		
	}
	
	
}
