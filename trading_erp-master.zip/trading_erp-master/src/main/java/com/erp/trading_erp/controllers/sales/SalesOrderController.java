package com.erp.trading_erp.controllers.sales;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.trading_erp.entities.sales.Sales_order;
import com.erp.trading_erp.services.sales.SalesOrderService;

@RestController
@CrossOrigin
@RequestMapping("/salesOrder")
public class SalesOrderController {

	
	@Autowired
	private SalesOrderService salesOrderService;
	
	@PostMapping("/placeSalesOrder")
	public Sales_order placeSalesOrder(@RequestBody Sales_order order) {
		System.out.println(order.toString());
		return salesOrderService.placeSalesOrder(order);
	}
	
	@GetMapping("/get-salesOrderList")
	public List<Sales_order> getAllSalesOrder() {
		return salesOrderService.getAllSaleOrder();
	}
	
	
}
