package com.erp.trading_erp.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.purchase.SupplierRepository;
import com.erp.trading_erp.entities.purchase.Supplier;
import com.erp.trading_erp.exception.SupplierException;

@Service
public class SupplierService {

	@Autowired
	private SupplierRepository supplierRepository;

	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Supplier registerSupplier(Supplier supplier) {
		//check if supplier already exist or not
		System.out.println(supplier);
		Supplier supplier1 = supplierRepository.getSupplierByName(supplier.getSupplier_name());
		System.out.println(supplier1+"**************");
		if (supplier1 ==  null) {
			return (Supplier) supplierRepository.save(supplier);
		} else {
			throw new SupplierException("Supplier Already exist!");
		}
		
		
	}

	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Supplier updateSupplier(Supplier supplier) {
		return (Supplier) supplierRepository.save(supplier);
	}

	public List<Supplier> fetchAllSupplier() {
		return	supplierRepository.fetchEntities(Supplier.class);
	}

	public Supplier fetchSupplierById(int id) {
		return supplierRepository.findByPK(Supplier.class, id);
	}
	
	
	
	
	
	

}
