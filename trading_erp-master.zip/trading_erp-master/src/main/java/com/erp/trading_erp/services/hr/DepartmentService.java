package com.erp.trading_erp.services.hr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.hr.DepartmentRepositrory;
import com.erp.trading_erp.entities.hr.Department;
import com.erp.trading_erp.exception.DepartmentException;

@Service
public class DepartmentService {

	
	@Autowired
	private DepartmentRepositrory departmentRepositrory;
	
	
	public List<Department> getAllDepartment() {
		return  departmentRepositrory.getAllDepartments();
	}
	
	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Department saveDepartment(Department dept) {
		//check if depatment is already exist or not then go ahead
		Department dept1 =    departmentRepositrory.getDepartmentByDeptName(dept);
		if (dept1 == null) {
			return departmentRepositrory.createNewDept(dept);
		}else {
			throw new DepartmentException("Departmetn with this name is already present");
		}
		
	}
	
	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Department updateDepartment(Department dept) {
		return departmentRepositrory.updateDept(dept);
	}
	
	
	
}
