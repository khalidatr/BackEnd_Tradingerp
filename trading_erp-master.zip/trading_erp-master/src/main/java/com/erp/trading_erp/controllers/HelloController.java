package com.erp.trading_erp.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@GetMapping("/hello")
	public String sayHi() {
		System.out.println("**********");
		return "Hi";
	}
}
