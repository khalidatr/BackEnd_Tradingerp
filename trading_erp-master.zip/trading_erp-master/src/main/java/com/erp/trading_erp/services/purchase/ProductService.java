package com.erp.trading_erp.services.purchase;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.erp.trading_erp.dao.purchase.ProductRepository;
import com.erp.trading_erp.entities.purchase.Product;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	
	public List<Product> getAllProduct(){
	return	productRepository.fetchEntities(Product.class);
		
	}
	
	@Transactional
	public Product registerProduct( Product product) {
		System.out.println("*************************");
		System.out.println(product.toString());
		int supplier_id = product.getSuppliers().get(0).getSupplier_id();
		System.out.println(supplier_id);
		
		return (Product) productRepository.save(product);
	}
	
	@Transactional
	public Product updateProduct( Product product) {
		return (Product) productRepository.save(product);
	}
	
	public Product getProductById(int id){
		return	productRepository.findByPK(Product.class, id);
			
		}

	
	
}
