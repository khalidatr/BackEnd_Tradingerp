package com.erp.trading_erp.entities.purchase;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.erp.trading_erp.entities.sales.Sales_order;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table
@DynamicUpdate
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(updatable = false)
	private int product_id;
	
	
	@Enumerated(EnumType.STRING)
	private Unit unit;
	
	private double price;
	private int quantity;
	
	private String product_name;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "category_id")
	@JsonIgnore
	private Categories category;


	@ManyToMany(cascade = { CascadeType.MERGE  })
    @JoinTable(
        name = "product_supplier", 
        joinColumns = { @JoinColumn(name = "product_id") }, 
        inverseJoinColumns = { @JoinColumn(name = "supplier_id") }
    )
	@JsonIgnoreProperties("products")
   private  List<Supplier> suppliers;
	
	
	
	
	




	public int getProduct_id() {
		return product_id;
	}



	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}



	public Unit getUnit() {
		return unit;
	}



	public void setUnit(Unit unit) {
		this.unit = unit;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public String getProduct_name() {
		return product_name;
	}



	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}



	public List<Supplier> getSuppliers() {
		return suppliers;
	}



	public void setSuppliers(List<Supplier> suppliers) {
		this.suppliers = suppliers;
	}



	public Categories getCategory() {
		return category;
	}



	public void setCategory(Categories category) {
		this.category = category;
	}



	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", unit=" + unit + ", price=" + price + ", quantity=" + quantity
				+ ", product_name=" + product_name + ", suppliers=" + suppliers + ", category=" + category + "]";
	}
	
	
	
	
	
	
	
	
	
}
