package com.erp.trading_erp.entities.hr;

public enum Role {

	ADMIN,
	HR,
	PURCHASE_ENGINEER,
	SALES_PERSON,
	MARKETING_PERSON
}
