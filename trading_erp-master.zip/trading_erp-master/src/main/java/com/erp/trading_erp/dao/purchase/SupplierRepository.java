package com.erp.trading_erp.dao.purchase;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.purchase.Supplier;

@Repository
public class SupplierRepository extends GenericRepository {

	
	//method to getAllSupplierList
	public List<Supplier> getAllSupplier() {
		return fetchEntities(Supplier.class);
	}
	
	public Supplier getSupplierByName(String supplierName) {
		Supplier supplier = null;
		try {
			supplier = 	(Supplier) entityManager.createQuery("select c from Supplier as c where c.supplier_name=:em ")
					.setParameter("em", supplierName)
					.getSingleResult();
			return supplier;
		} catch (NoResultException e) {
			return supplier;
		}
		
	
	}
	
}
