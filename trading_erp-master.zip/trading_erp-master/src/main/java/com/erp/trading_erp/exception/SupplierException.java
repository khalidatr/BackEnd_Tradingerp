package com.erp.trading_erp.exception;

public class SupplierException extends RuntimeException {

	public SupplierException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SupplierException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
