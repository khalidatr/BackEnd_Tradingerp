package com.erp.trading_erp.services.purchase;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erp.trading_erp.dao.purchase.ProductRepository;
import com.erp.trading_erp.dao.purchase.ProductRepository2;
import com.erp.trading_erp.dao.purchase.PurchaseOrderRepository;
import com.erp.trading_erp.dto.PurchaseOrder_DTO;
import com.erp.trading_erp.entities.purchase.Product;
import com.erp.trading_erp.entities.purchase.PurchaseOrderDetails;
import com.erp.trading_erp.entities.purchase.Purchase_Order;
import com.erp.trading_erp.entities.purchase.Supplier;

@Service
public class PurchaseOrderService {

	
		@Autowired
		private PurchaseOrderRepository purchaseOrderRepository;
		
		@Autowired
		private ProductRepository productRepository;
		
		@Autowired
		private ProductRepository2 productRepository2;
		
		

		
		@Transactional
		public Purchase_Order placeOrder(Purchase_Order order) {
			
			return 	(Purchase_Order)	purchaseOrderRepository.save(order);
			
		}
		
//		@Transactional
//		public void placeOrder(PurchaseOrder_DTO order) {
//			Purchase_Order pu_order =   convertToPurchaseOrder(order);
//			int supplier_id = order.getSuppplier_id();
//			List<Product>productList = pu_order.getProducts();
//			
//			//now place the order 
//			Purchase_Order purchase_order = 	(Purchase_Order)	purchaseOrderRepository.save(pu_order);
//			int po_number = purchase_order.getPo_id();
//			System.out.println(po_number);
//			//now iterate over the list of product from order
//			//one by one update product quantity and price =>first get the previous quantity and add the new quantity into it
//			//now do an entry into purchase order details table 
//			
//			System.out.println("Before going into for looop ###############");
//			for(Product product : productList) {
//				int b_quantity = product.getQuantity();
//				double price = product.getPrice();
//				int product_id = product.getProduct_id();
//				
//				System.out.println("**********");
//				System.out.println(product.getProduct_name());
//				System.out.println(product.getQuantity()+" ye quantity request se aa rhi hai");
//				//get the product entity from the database table
//				//Product product2 = productRepository.getProductByProductName(product.getProduct_name());
//				Product product2 =   productRepository2.findById(product.getProduct_id()).get();
//				System.out.println("product2 ref var printing here ............................");
//				System.out.println(product2);
//				
//				//get the quantity and price and update the quantity and price
//				int p_quantity = product2.getQuantity();
//				System.out.println(p_quantity+"ye database se aa rha hai");
//				int quant = p_quantity+b_quantity;
//				//now update the quantity
//				product2.setQuantity(quant);
//				System.out.println(product2);
//				//update the price
//				product2.setPrice(price);
//				//persist the changes
//		
//				
//			
//
//
//			System.out.println("after update entity ***********************");
//				//make entry into purchase_order_detail table
//				PurchaseOrderDetails purchDetail = new PurchaseOrderDetails();
//				purchDetail.setQuantity(b_quantity);
//				purchDetail.setPo_id(po_number);
//				purchDetail.setProduct_id(product_id);
//				//now persist both the record into db
//
//				productRepository.save(purchDetail);
//			}
//			
//			
//			
//			
//		}
		
		//method to convert purchase order dto to purchase order
		public Purchase_Order convertToPurchaseOrder(PurchaseOrder_DTO order) {
			Purchase_Order pu_order = new Purchase_Order();
			pu_order.setAdvance_amount(order.getAdvance_amount());
			pu_order.setDue_amount(order.getDue_amount());
			pu_order.setDue_date(order.getDue_date());
			pu_order.setPayment_type(order.getPayment_type());
			pu_order.setProducts(order.getProducts());
			pu_order.setPurchase_date(order.getPurchase_date());
			pu_order.setPurchase_time(order.getPurchase_time());
			pu_order.setTotal_amount(order.getTotal_amount());
			Supplier supplier = purchaseOrderRepository.findByPK(Supplier.class, order.getSuppplier_id());
			pu_order.setSuppplier(supplier);
			return pu_order;
			
		}
		
		public List<Purchase_Order> getOrderList() {
		return	purchaseOrderRepository.fetchEntities(Purchase_Order.class);
		}
		
		
		
}
