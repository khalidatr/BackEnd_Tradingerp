package com.erp.trading_erp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

@Repository
public class GenericRepository  {

	@PersistenceContext
	protected EntityManager entityManager;
	
	
	
	
	@Transactional
	public Object save(Object obj) {
		//merge can be used for insert and update both
		return entityManager.merge(obj);
	}
	
	
	
	
	
	public <E> E findByPK(Class<E> clazz, Object pk) {
		return entityManager.find(clazz, pk);
		
	}
	
	

	
	//getting and entity by its one of columnname 
			@SuppressWarnings("unchecked")
			public <E> E findByField(Class<E> clazz, String colValue,String columnName) {
		
				String className=clazz.getName();
				String hql1 = " from "+className+"  c where  c."+columnName+" = "+colValue;
				return (E) entityManager.createQuery(hql1)
				.getResultList().get(0);
			}
	
	
	//	"FROM Employee E WHERE E.id = 10";
	
	
	@SuppressWarnings("unchecked")
	public <T> List<T>    fetchEntities(Class<T> clazz) {
		return (List<T>) entityManager.createQuery(" select c from "+clazz.getName()+" as c")
				.getResultList();
			
	}
}
