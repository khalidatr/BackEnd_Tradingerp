package com.erp.trading_erp.entities.purchase;

public enum Unit {
	
	UNIT,
	KG,
	BAGS,
	BOTTLES,
	NOS,
	LITRE,
	PIECES,
	ROLLS,
	CANS,
	BUCKETS,
	BOX,
	SQUARE_METERS,
	SQUARE_FEET,
	PAIRS,
	DOZEN,
	CARTOONS
	
}
