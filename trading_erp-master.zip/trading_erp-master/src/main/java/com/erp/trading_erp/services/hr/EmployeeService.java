package com.erp.trading_erp.services.hr;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.erp.trading_erp.dao.hr.EmployeeRepository;
import com.erp.trading_erp.dao.hr.EmployeeRepository2;
import com.erp.trading_erp.dto.EmployeeRecord;
import com.erp.trading_erp.entities.hr.Department;
import com.erp.trading_erp.entities.hr.Employee;
import com.erp.trading_erp.entities.hr.Login;
import com.erp.trading_erp.entities.hr.Roles;
import com.erp.trading_erp.exception.EmployeeIDNotFoundException;
import com.erp.trading_erp.exception.LoginServiceException;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private EmployeeRepository2 employeeRepository2;
	

	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Employee saveEmployee(Employee employee) {
		// data validation on
		return employeeRepository.save(employee);

	}

	@Transactional(timeout = 60, rollbackFor = Exception.class)
	public Employee updateEmployee(Employee employee) {
		// data validation on
		Employee employee2;
		boolean doesExist = employeeRepository.existsById(employee.getEmpid());
		if (doesExist) {
			employee2 = employeeRepository.save(employee);
			return employee2;
		} else {
			throw new EmployeeIDNotFoundException();
		}

	}

	public Optional<Employee> getEmployee(int id) {
		try {
			return employeeRepository.findById(id);
		} catch (RuntimeException e) {
			throw new EmployeeIDNotFoundException();
		}

	}

	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	
	public List<Object[]> FetchEmployeeRecords() {
	return 	 employeeRepository2.fetchEmployeeRecords();
			
	}
	
	public Login login(Login loginDetails) {
		try {
			return employeeRepository2.findByUsernameAndPwd(loginDetails.getUsername(), loginDetails.getPassword());
					
		} catch (EmptyResultDataAccessException e) {
			throw new LoginServiceException("Invalid username or password");
		}
		
	}
	

}
