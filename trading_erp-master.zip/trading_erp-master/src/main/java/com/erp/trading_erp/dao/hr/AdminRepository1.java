package com.erp.trading_erp.dao.hr;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.Repository;

import com.erp.trading_erp.entities.hr.Employee;

public interface AdminRepository1 extends JpaRepository<Employee, Integer>{

}
