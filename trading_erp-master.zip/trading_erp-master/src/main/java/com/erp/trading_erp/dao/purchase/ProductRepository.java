package com.erp.trading_erp.dao.purchase;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.erp.trading_erp.dao.GenericRepository;
import com.erp.trading_erp.entities.purchase.Product;

@Repository
public class ProductRepository  extends GenericRepository{

	
	public List<Product> getAllProduct(){
		return fetchEntities(Product.class);
	}
	
	
	public Product registerProduct( Product product) {
		//check if product is already exist or not 
		System.out.println("*************************");
		System.out.println(product.toString());
		
		Product product1 = null;
		try {
		product1 = 	findByField(Product.class, product.getProduct_name(), "product_name");
		if (product1 == null) {
			return (Product) save(product);
		}
		} catch (NoResultException e) {
			return product1;
		}
		return product1;
	}
	
	
	public Product updateProduct( Product product) {
		//check if product is already exist or not 
		Product product1 = null;
		try {
		
			product1 = entityManager.merge(product);
			return product1;
		}
		 catch (NoResultException e) {
			
		}
		return product1;
	}
	
	
	public Product getProductById( int id){
		Product product = null;
		try {
			product =  findByPK(Product.class, id);
			return product;
		} catch (NoResultException e) {
			// TODO: handle exception
		}
		return product;
		
	}
	
	public Product getProductByProductName(String  name){
		Product product = null;
		System.out.println("in repo &&&&&&&&"+name);
		try {
			product =  (Product) entityManager.createQuery(" select c from Product  c where c.product_name =:em ")
					.setParameter("em", name)
					.getSingleResult();
			System.out.println(product.getProduct_name());
			return product;
		} catch (NoResultException e) {
			// TODO: handle exception
			return product;
		}
	
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
